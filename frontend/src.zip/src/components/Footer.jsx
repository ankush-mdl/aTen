import React from "react";
import "../assets/components/Footer.css";

export default function Footer() {




  return (
    <>
    <nav className="footer">

    </nav></>
  );
}



